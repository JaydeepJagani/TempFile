<?php

namespace Wpai\Scheduling\Exception;

/**
 * Class SchedulingHttpException
 * @package Wpai\Scheduling\Exception
 */
class SchedulingHttpException extends \Exception
{

}