<?php 
	$con = new mysqli('localhost','root','root','Quote_DB');
		if(mysqli_connect_errno()){
			echo "can not connect to datbase";
			exit;
		}
	include('simplehtmldom_1_5/simple_html_dom.php');
	echo "<pre>";
	$quote = array();
	$counter = 0;
	
		$html = file_get_html('http://quotations.about.com/od/inspirationquotes/');	
		foreach($html->find('div[class=articles-content] div[class=article-unit-img-wrapper] div[class=article-unit-desc]') as $element) 
		{	
			foreach($element->find('h5[class=heading] a') as $innerelement) 
			{	
				$quote[$counter]['category'] = trim($innerelement->innertext);
			}
			foreach($element->find('a[class=article-blurb]') as $innerelement) 
			{	
				$quote[$counter]['quote'] = trim(str_replace('\'','\'\'',str_replace('"','',$innerelement->innertext)));
			}
			// foreach($element->find('a[class=article-blurb]') as $innerelement) 
			// {	
			// 	$quote[$counter]['quote'] = trim($innerelement->innertext);
			// }
			$insertQuery = "insert into Quote1 (vQuate,vCategory) values('".$quote[$counter]['quote']."','".$quote[$counter]['category']."');";
			$result = $con->query($insertQuery);
			$counter++;	
		}
		foreach($html->find('div[class=content widget] div[class=category-list] ul li a') as $element) 
		{	
			$link = $element->href;
			$pagehtml = file_get_html($link);	

			// Direct quote given in the page 
				foreach($pagehtml->find('div[class=articles-content] div[class=article-unit-img-wrapper] div[class=article-unit-desc]') as $element) 
				{	
					foreach($element->find('h5[class=heading] a') as $innerelement) 
					{	
						$quote[$counter]['category'] = trim($innerelement->innertext);
						
					}

					foreach($element->find('a[class=article-blurb]') as $innerelement) 
					{	
						$quote[$counter]['quote'] = trim(str_replace('\'','\'\'',str_replace('"','',$innerelement->innertext)));
					}

					// foreach($element->find('a[class=article-blurb]') as $innerelement) 
					// {	
					// 	$quote[$counter]['quote'] = trim($innerelement->innertext);
					// }
					$insertQuery = "insert into Quote1 (vQuate,vCategory) values('".$quote[$counter]['quote']."','".$quote[$counter]['category']."');";
					$result = $con->query($insertQuery);
					
					$counter++;	
				}

				// Quote in the give subcategory pages if given.
				foreach($pagehtml->find('div[class=content widget] div[class=category-list] ul li a') as $innerelement) 
				{	
					$link = $innerelement->href;
					$innerpagehtml = file_get_html($link);	
					foreach($innerpagehtml->find('div[class=articles-content] div[class=article-unit-img-wrapper] div[class=article-unit-desc]') as $element) 
					{	
						foreach($element->find('h5[class=heading] a') as $innerelement) 
						{	
							$quote[$counter]['category'] = trim($innerelement->innertext);
						}
						foreach($element->find('a[class=article-blurb]') as $innerelement) 
						{	
							$quote[$counter]['quote'] = trim(str_replace('\'','\'\'',str_replace('"','',$innerelement->innertext)));
						}
						// foreach($element->find('a[class=article-blurb]') as $innerelement) 
						// {	
						// 	$quote[$counter]['quote'] = trim($innerelement->innertext);
						// }
						$insertQuery = "insert into Quote1 (vQuate,vCategory) values('".$quote[$counter]['quote']."','".$quote[$counter]['category']."');";
						$result = $con->query($insertQuery);
						$counter++;	
					}
				}
		}
		
		// print_r(json_encode($quote));

?>