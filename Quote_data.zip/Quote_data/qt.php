<?php 
	include('simplehtmldom_1_5/simple_html_dom.php');
	$quote = array();
	$counter = 0;

		$html = file_get_html('http://www.successories.com/iquote/category/39/inspirational-quotes/');	
		
		foreach($html->find('div.quotebox') as $element) 
		{	
			foreach($element->find('div[class=quote] a') as $innerelement) 
			{	
				echo $innerelement->innertext."<br/>";
				//$quote[$counter]['quote'] = str_replace('\'','\'\'',str_replace('"','',$innerelement->innertext));
				
			}	

			// foreach($element->find('div[class=aboutquote]') as $innerelement) 
			// {	
			// 	foreach($innerelement->find('span[class=author]') as $authordata) 
			// 	{		
			// 		$innerdata = $authordata->find('a',0);
			// 		$quote[$counter]['author'] = $innerdata->innertext;	
			// 	}

			// 	foreach($innerelement->find('a') as $categorydata) 
			// 	{		
			// 		$quote[$counter]['category'] = $categorydata->innertext;
			// 	}
			// 	// $category  = $innerelement->find('a',0);
			// 	// $quote[$counter]['category'] = $category->innertext;
			// }	
			// $insertQuery = "insert into Quote (vQuate,vAuthor,vCategory) values('".$quote[$counter]['quote']."','".$quote[$counter]['author']."','".$quote[$counter]['category']."');";
			// $result = $con->query($insertQuery);
			// $id = $con->insert_id;

			// echo $counter."<br/>";
			// print_r($insertQuery);
			// echo "<br/>";
			$counter++;	
		}
		
	

	// 	print_r($quote);
	// 	echo "<br/>";	

?>