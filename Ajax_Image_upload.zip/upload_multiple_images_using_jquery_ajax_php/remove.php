<?php
$conn = mysqli_connect('localhost','root','root','image_upload_exm');
	if(mysqli_connect_errno()){
		echo "can not connect to datbase";
		exit;
	}
if(isset($_POST['id'])) {
	$sql = 'DELETE FROM images where iId = '.$_POST['id'];
	if (mysqli_query($conn, $sql)) {
	   echo '1';
	}else{
		echo '0';
	}
}