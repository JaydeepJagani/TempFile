<?php 
	require_once("../wp-load.php");
	include('simplehtmldom_1_5/simple_html_dom.php');
	$html = file_get_html('http://blog.longfield-gardens.com/all');
	$category ='';
	$poemdata = array();
	$counter = 0;
	foreach($html->find('div.body-container div.content-wrapper div.row-number-3 div.blog-content div.post-item') as $element) 
	{	
			// $atag = $element->find('div.post-header h2 a',0)->href;
			$defaults = array(
			        'post_author' => 1,
			        'post_status' => 'publish',
			        'post_type' => 'post',
			        'comment_status' => '',
			        'ping_status' => '',
			        'post_password' => '',
			        'to_ping' =>  '',
			        'pinged' => '',
			        'post_parent' => 0,
			        'menu_order' => 0,
			        'guid' => '',
			        'import_id' => 0,
			        'context' => '',
			    );
			// $defaults['post_title']  =$element->find('h2 a',0)->plaintext;
			// $defaults['post_name']  = str_replace('http://blog.longfield-gardens.com/','', $element->find('h2 a',0)->href);
			$innerhtml = file_get_html($element->find('h2 a',0)->href); 			
			foreach($innerhtml->find('div.widget-type-blog_content') as $innerelement) 
			{
				// $date = preg_replace('/<span\b[^>]*>(.*?)<\/span>/i', '', $innerelement->find('#hubspot-author_data',0)->innertext);
				// $date = preg_replace('/<a\b[^>]*>(.*?)<\/a>/i', '', $date);
				// $date = str_replace('on ', '', $date);
				// $defaults['post_date'] = date("Y-m-d h:i:s", strtotime($date));
				$defaults['post_content'] = $innerelement->find('div.post-body span',0)->innertext;
				$imghtml = str_get_html($defaults['post_content']);
				foreach ($imghtml->find('img') as $img) {
					$imgsrc = explode('?', $img->src);
					$img->src = $imgsrc[0];
				}
				$defaults['post_content']  = $imghtml->save();
			}
			// $catArr = array();
			// foreach ($innerhtml->find('p#hubspot-topic_data a') as $category) {

			// 	if(!empty($category->plaintext) &&  $category->plaintext != 'Indoor Bulbs'){
			// 		$cat = get_term_by( 'name', $category->plaintext,'category');
			// 		if(empty($cat)) {
			// 			$catid = wp_insert_term(
			// 			  $category->plaintext, // the term 
			// 			  'category'
			// 			);
			// 			$catArr[] = $catid['term_id'];
			// 		}else{
			// 			$catArr[] = $cat->term_id;
			// 		}
			// 	}
			// }
			echo "<pre>";print_r($defaults);exit;
			$defaults['post_category'] = $catArr;
			$postid = wp_insert_post( $defaults, true );
	}
echo "Data inserted ";
exit();

?>