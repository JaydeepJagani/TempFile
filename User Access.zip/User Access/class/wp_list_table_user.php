<?php
if ( ! class_exists( 'WP_List_Table' ) ) {
	require_once( ABSPATH . 'wp-admin/includes/class-wp-list-table.php' );
}

class User_List_Table extends WP_List_Table {
	/** Class constructor */
	public function __construct() {

		parent::__construct( [
			'singular' => __( 'user', 'sp' ), //singular name of the listed records
			'plural'   => __( 'users', 'sp' ), //plural name of the listed records
			'ajax'     => false 
		] );

	}

	/**
	* Retrieve campaign data from the database
	*
	* @param int $per_page
	* @param int $page_number
	*
	* @return mixed
	*/
	public static function get_user_list( $per_page = 5, $page_number = 1 ) {

	  global $wpdb;

	  $args = array(
	    'post_type' => ACCESS_POST_TYPE,
	    'posts_per_page' => $per_page,
	    'paged' => $page_number
	  );

	  $i = 0;
	  $args['meta_query']['relation'] = 'AND';
	  if (isset($_GET['access_user']) && $_GET['access_user']) {
	  	$args['meta_query'][] = array(
		    'key'     => '_access_user',
		    'value'   => $_GET['access_user'],
		    'compare' => '='
		);
		$i++;
	  }

	  if (isset($_GET['access_status']) && $_GET['access_status']) {
	  	$args['meta_query'][] = array(
		    'key'     => '_access_status',
		    'value'   => $_GET['access_status'],
		    'compare' => '='
		);
	  }

	  if (isset($_GET['startdate']) && $_GET['startdate']) {
	  	$startdate = strtotime($_GET['startdate']);
	  	$args['meta_query'][] = array(
		    'key'     => '_access_start_date',
		    'value'   => $startdate,
		    'compare' => '>'
		);
	  }

	  if (isset($_GET['enddate']) && $_GET['enddate']) {
	  	$enddate = strtotime($_GET['enddate']);
	  	$args['meta_query'][] = array(
		    'key'     => '_access_end_date',
		    'value'   => $enddate,
		    'compare' => '<'
		);
	  }

	  $wp_query = new WP_Query( $args );

	  $result = array();
	  $key = 0;
	  while ($wp_query->have_posts()) { $wp_query->the_post();
	  	$result[$key] = (array) get_post(get_the_ID());
	  	$meta = get_post_meta(get_the_ID());
	  	$result[$key]['_access_start_date'] = $meta['_access_start_date'][0];
	  	$result[$key]['_access_end_date'] = $meta['_access_end_date'][0];
	  	$result[$key]['_access_status'] = $meta['_access_status'][0];
	  	$result[$key]['_last_accesses_by_ip'] = $meta['_last_accesses_by_ip'][0];
	  	$result[$key]['_access_medium'] = $meta['_access_medium'][0];
	  	$result[$key]['_access_remarks'] = $meta['_access_remarks'][0];
	  	$portfolios = get_post_meta( get_the_ID(), '_accessible_portfolios', true );
      	$category = array();
      	foreach ( $portfolios as $portfolio ) {
          	$categories = get_post_meta( $portfolio, 'technology_options', true );
        	$category = array_merge( $categories, $category );
      	}
        $result[$key]['_technology_option'] = implode( ", ", array_unique( $category ) );
        $user = get_user_by( 'id', $meta['_access_user'][0] );
        if (!empty($user)) {
        	$result[$key]['user_login'] = $user->data->display_name;
        	$result[$key]['user_email'] = $user->data->user_email;
        	$result[$key]['user_name'] = $user->data->user_login;
        }else{
        	$result[$key]['user_login'] = 'N/A';
        }
        $key++;
	  }
	 
	  return $result;
	}

	/**
	 * Render the bulk edit checkbox
	 *
	 * @param array $item
	 *
	 * @return string
	 */
	function column_cb($item){
	    return sprintf(
	   		'<input type="checkbox" name="act-ina-access[]" %s value="%s" />', $checked, $item['ID']
	  	);
	}
	
	/**
	 * Method for name column
	 *
	 * @param array $item an array of DB data
	 *
	 * @return string
	 */
	function column_name( $item ) {

	  $title = '<strong>' . $item['name'] . '</strong>';

	  $actions = [
	    'delete' => sprintf( '<a href="?page=%s&action=%s&campaign=%s&_wpnonce=%s">Delete</a>', esc_attr( $_REQUEST['page'] ), 'delete', absint( $item['iCampaignId'] ), $delete_nonce ),
	    'active' => sprintf( '<a href="?page=%s&action=%s&campaign=%s&_wpnonce=%s">Active</a>', esc_attr( $_REQUEST['page'] ), 'active', absint( $item['iCampaignId'] ), $active_nonce ),
	    'inactive' => sprintf( '<a href="?page=%s&action=%s&campaign=%s&_wpnonce=%s">Inactive</a>', esc_attr( $_REQUEST['page'] ), 'inactive', absint( $item['iCampaignId'] ), $inactive_nonce ),
	  ];

	  return $title . $this->row_actions( $actions );
	}

	/**
	 * Render a column when no column specific method exists.
	 *
	 * @param array $item
	 * @param string $column_name
	 *
	 * @return mixed
	 */
	public function column_default( $item, $column_name ) {

	  switch ( $column_name ) {
	    case 'user_login': 
	    		return '<a href="'.admin_url('admin.php?page=add_user_access&ID='.$item['ID']).'">'.$item[ $column_name ].'</a>'.'<br>'.$item['user_email']; 
	    		break;
	    case '_access_medium':
	    		return $item[ $column_name ]?"<strong>Medium -</strong> " . $item[ $column_name ] . "<br>" . $item['_access_remarks']:'';
	    		break;
	    case '_technology_option':
	    		return $item[ $column_name ];
	    		break;
	   	case '_access_start_date':
	    		return $item[ $column_name ]?date('F j, Y', $item[ $column_name ]):'';
	    		break;
	    case '_access_end_date':
	    		return $item[ $column_name ]?date('F j, Y', $item[ $column_name ]):'';
	    		break;
	    case '_access_status':
	    		$status = $item[ $column_name ]?$item[ $column_name ]:'Inactive';
	    		$status = $status=='Inactive'?'<span class="label label-danger">Inactive</span>':'<span class="label label-primary">Active</span>';
	    		return $status;
	    		break;
	    case '_last_accesses_by_ip':
	    		return $item[ $column_name ];
	    		break;
	    case 'user_name':
	    		return '<a class="badge" href="'.admin_url( "users.php?page=login_log&filter=" . $item[ $column_name ] ).'" target="_blank">View</a>';
	    		break;

	      return $item[ $column_name ];
	    default:
	      return print_r( $item, true ); //Show the whole array for troubleshooting purposes
	  }
	}

	
	/**
	 *  Associative array of columns
	 *
	 * @return array
	 */
	function get_columns() {
	  $columns = [
	    'cb'      => '<input type="checkbox" />',
	    'user_login'    => __( 'User', 'sp' ),
	    '_access_medium' => __( 'Remarks', 'sp' ),
	    '_technology_option'    => __( 'Category', 'sp' ),	
	    '_access_start_date'    => __( 'Start Date', 'sp' ),	
	    '_access_end_date'    => __( 'End Date', 'sp' ),
	    '_access_status'    => __( 'Access Status', 'sp' ),	
	    'user_name'    => __( 'History', 'sp' ),	
	  ];
	  return $columns;
	}

	/**
	 * Returns the count of records in the database.
	 *
	 * @return null|string
	 */
	public static function record_count() {
		  $args = array(
		    'post_type' => ACCESS_POST_TYPE,
		    'posts_per_page' => 5,
		  );
		  $wp_query = new WP_Query( $args );
	      return $wp_query->found_posts;
	}
	
	/**
	 * Handles data query and filter, sorting, and pagination.
	 */
	public function prepare_items() {

	  $this->_column_headers = $this->get_column_info();
	  /** Process bulk action */
	  $this->process_bulk_action();

	  $per_page     = $this->get_items_per_page( 'access_per_page', 10 );
	  $current_page = $this->get_pagenum();
	  $total_items  = self::record_count();

	  $this->set_pagination_args( [
	    'total_items' => $total_items, //WE have to calculate the total number of items
	    'per_page'    => $per_page //WE have to determine how many items to show on a page
	  ] );

	  $this->items = self::get_user_list( $per_page, $current_page );
	}

	/**
	 * Returns an associative array containing the bulk action
	 *
	 * @return array
	 */
	public function get_bulk_actions() {
	  $actions = [
	    'delete-access' => 'Delete',
	    'active-access' => 'Active',
	    'inactive-access' => 'Inactive',
	  ];

	  return $actions;
	}

	/**
	 * Active record.
	 */
	public static function active_access( $request_param ) {
		foreach ($request_param as $post_id) {
			update_post_meta( $post_id, '_access_status', 'Active' );
		}
	}

	/**
	 * Inactive record.
	 */
	public static function inactive_access	( $request_param ) {
		foreach ($request_param as $post_id) {
			update_post_meta( $post_id, '_access_status', 'Inactive' );
		}
	}

	/**
	 * Delete record.
	 */
	public static function delete_access( $request_param ) {
		foreach ($request_param as $post_id) {
			wp_delete_post($post_id, true);
		}
	}

	public function process_bulk_action() {
		  //Detect when a bulk action is being triggered...
		  if ( 'Active' === $this->current_action() ) {

		    // In our file that handles the request, verify the nonce.
		    $nonce = esc_attr( $_REQUEST['_wpnonce'] );

		    if ( ! wp_verify_nonce( $nonce, 'sp_apply_access' ) ) {
		      die( 'Go get a life script' );
		    }
		    else {
		      self::active_access( $_REQUEST['act-ina-access'] );

		      wp_redirect( admin_url( 'admin.php?page=wp_list_table_class' ) );
		      exit;
		    }

		  }

		  // If the delete bulk action is triggered
		  if ( ( isset( $_POST['action'] ) && $_POST['action'] == 'active-access' )
		       || ( isset( $_POST['action2'] ) && $_POST['action2'] == 'active-access' )
		  ) {

		    // loop over the array of record iCampaignPrizeIds and delete them
		    self::active_access( $_REQUEST['act-ina-access'] );
			wp_redirect( admin_url( 'admin.php?page=wp_list_table_class' ) );
		    exit;
		  }

		  //Detect when a bulk action is being triggered...
		  if ( 'Inactive' === $this->current_action() ) {

		    // In our file that handles the request, verify the nonce.
		    $nonce = esc_attr( $_REQUEST['_wpnonce'] );

		    if ( ! wp_verify_nonce( $nonce, 'sp_apply_access' ) ) {
		      die( 'Go get a life script' );
		    }
		    else {
		      self::inactive_access( $_REQUEST['act-ina-access'] );

		      wp_redirect( admin_url( 'admin.php?page=wp_list_table_class' ) );
		      exit;
		    }

		  }

		  // If the delete bulk action is triggered
		  if ( ( isset( $_POST['action'] ) && $_POST['action'] == 'inactive-access' )
		       || ( isset( $_POST['action2'] ) && $_POST['action2'] == 'inactive-access' )
		  ) {

		    // loop over the array of record iCampaignPrizeIds and delete them
		    self::inactive_access( $_REQUEST['act-ina-access'] );
			wp_redirect( admin_url( 'admin.php?page=wp_list_table_class' ) );
		    exit;
		  }

		  //Detect when a bulk action is being triggered...
		  if ( 'Delete' === $this->current_action() ) {

		    // In our file that handles the request, verify the nonce.
		    $nonce = esc_attr( $_REQUEST['_wpnonce'] );

		    if ( ! wp_verify_nonce( $nonce, 'sp_apply_access' ) ) {
		      die( 'Go get a life script' );
		    }
		    else {
		      self::delete_access( $_REQUEST['act-ina-access'] );

		      wp_redirect( admin_url( 'admin.php?page=wp_list_table_class' ) );
		      exit;
		    }

		  }

		  // If the delete bulk action is triggered
		  if ( ( isset( $_POST['action'] ) && $_POST['action'] == 'delete-access' )
		       || ( isset( $_POST['action2'] ) && $_POST['action2'] == 'delete-access' )
		  ) {

		    // loop over the array of record iCampaignPrizeIds and delete them
		    self::delete_access( $_REQUEST['act-ina-access'] );
			wp_redirect( admin_url( 'admin.php?page=wp_list_table_class' ) );
		    exit;
		  }
	}

	function extra_tablenav( $which ) {
	    global $wpdb;
	    if ( $which == "top" ){
	    	$users = get_users( 'role=subscriber' );
			$curr_user = $_GET['access_user'];

			$status = array('Active', 'Inactive');
			$curr_status = $_GET['access_status'];

			$curr_start_date = $_GET['startdate'];
			$curr_end_date = $_GET['enddate'];
			
	        ?>
	        <div class="alignright actions bulkactions">
	            <select name="access_user" id="access_user">
					<option value="">All Users</option>
					<?php 
					foreach ($users as $key => $value) : ?>
							<option value="<?php echo $value->ID;?>" <?php echo ($curr_user== $value->ID ? 'selected="selected"' : '');?>><?php echo $value->data->display_name;?></option>
					<?php endforeach;?>					
				</select>
				<select name="access_status" id="access_status">
					<option value="">All Status</option>
					<?php foreach ($status as $key => $value) : ?>
							<option value="<?php echo $value;?>" <?php echo ($curr_status== $value ? 'selected="selected"' : '');?>><?php echo $value;?></option>
					<?php endforeach;?>					
				</select>
				<input type="text" value="<?php echo $curr_start_date?$curr_start_date:'';?>" name="startdate" id="dpd3" placeholder="Access From"/>
				<input type="text" value="<?php echo $curr_end_date?$curr_end_date:'';?>" name="enddate" id="dpd4" placeholder="Access To"/>
				<input type="button" value="Filter" class="button" id="access-filter" />
	        </div>
	        <?php
	    }
	}
}//end of class
