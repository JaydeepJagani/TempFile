<?php
if ( ! class_exists( 'WP_List_Table' ) ) {
	require_once( ABSPATH . 'wp-admin/includes/class-wp-list-table.php' );
}

class Portfolio_List_Table extends WP_List_Table {
	/** Class constructor */
	
	public function __construct() {
	
		parent::__construct( [
			'singular' => __( 'portfolio', 'sp' ), //singular name of the listed records
			'plural'   => __( 'portfolios', 'sp' ), //plural name of the listed records
			'ajax'     => false //should this table support ajax?

		] );
	}

	/**
	* Retrieve campaign data from the database
	*
	* @param int $per_page
	* @param int $page_number
	*
	* @return mixed
	*/
	public static function get_portfolio_list($post ) {

	  global $wpdb;
	 
		$args = array(
		  'numberposts'   => -1,
		  'post_type'     => 'portfolio',
		  'post_status' => 'publish' );
		$args['meta_query'] = array();
		$args['meta_query']['relation'] = 'AND';
		if($_GET['technology_options']){
			$args['meta_query'][]=array(
					'key' => 'technology_options',
					'value' => $_GET['technology_options'],
					'compare' => 'LIKE',
			);
		}
		if($_GET['category']){
			$args['meta_query'][]=array(
					'key' => 'category',
					'value' => $_GET['category'],
					'compare' => 'LIKE',
			);
		}
		if($_GET['industries']){
			$args['meta_query'][]=array(
					'key' => 'industries',
					'value' => $_GET['industries'],
					'compare' => 'LIKE',
			);
		}
	  $the_query = new WP_Query( $args );
	  $posts = array();
	  foreach ($the_query->posts as $key => $value) {
	  	$posts[$key] = (array)$value;
	  }
	  //echo "<pre>";print_r($posts);exit;
	  return $posts;	  
	}

	/**
	 * Render the bulk edit checkbox
	 *
	 * @param array $item
	 *
	 * @return string
	 */
	function column_cb($item){
		$post_id = $_REQUEST['ID'];
		$portfolios = get_post_meta( $post_id, '_accessible_portfolios', true );
		if (!empty($portfolios)) {
			foreach ($portfolios as $key => $value) {
				if ($item['ID'] == $value) {
					$checked = 'checked';
				}
			}
		}else{
			$checked = '';
		}
	    return sprintf(
	   		'<input type="checkbox" name="apply-access[]" %s value="%s" />', $checked, $item['ID']
	  	);
	}
	
	/**
	 * Method for name column
	 *
	 * @param array $item an array of DB data
	 *
	 * @return string
	 */
	function column_name( $item ) {

	  $title = '<strong>' . $item['name'] . '</strong>';

	  $actions = [
	    'delete' => sprintf( '<a href="?page=%s&action=%s&campaign=%s&_wpnonce=%s">Delete</a>', esc_attr( $_REQUEST['page'] ), 'delete', absint( $item['ID'] ), $delete_nonce ),
	  ];

	  return $title . $this->row_actions( $actions );
	}

	/**
	 * Render a column when no column specific method exists.
	 *
	 * @param array $item
	 * @param string $column_name
	 *
	 * @return mixed
	 */
	public function column_default( $item, $column_name ) {

	  switch ( $column_name ) {
	    case 'post_title': 
	    		return '<a href="'.admin_url('admin.php?page=edit_user_access&postid='.$item['ID']).'">'.$item[ $column_name ].'</a>'; 
	    		break;

	      return $item[ $column_name ];
	    default:
	      return print_r( $item, true ); //Show the whole array for troubleshooting purposes
	  }
	}

	
	/**
	 *  Associative array of columns
	 *
	 * @return array
	 */
	function get_columns() {
	  $columns = [
	    'cb'      => '<input type="checkbox" />',
	    'post_title'    => __( 'Title', 'sp' ),	
	  ];

	  return $columns;
	}

	
	
	/**
	 * Handles data query and filter, sorting, and pagination.
	 */
	public function prepare_items($postvalue) {
		$columns = $this->get_columns();
        $hidden = array();
        $sortable = array();

        $this->_column_headers = array($columns, $hidden, $sortable);

	  /** Process bulk action */
	  //$this->process_bulk_action();

	  

	  /** Process bulk action */
	  	$this->process_bulk_action();
        $columns = $this->get_columns();
        $hidden = array();
        $sortable = $this->get_sortable_columns();

        $this->_column_headers = array($columns, $hidden, $sortable);
        
        //This is the line:
        $this->items = self::get_portfolio_list($postvalue);
        //When the above line is commented, it works as expected (except for the lack of data, of course)

	}


	/**
	 * Returns an associative array containing the bulk action
	 *
	 * @return array
	 */
	public function get_bulk_actions() {
	  $actions = [
	    'apply-access' => 'access',
	  ];

	  return $actions;
	}

	/**
	 * Delete a route record.
	 *
	 * @param int $iportfolioID route iportfolioID
	 */
	public static function apply_access( $request_param ) {

		$user_id = $request_param['access_user'];
		$start = strtotime($request_param['startdate']);
		$end = strtotime($request_param['enddate']);
		$portfolios = $request_param['apply-access'];
		$medium = $request_param['access_medium'];
		$remarks = $request_param['access_remarks'];
		$campaign_source = $request_param['campaign_source'];
		$campaign_medium = $request_param['campaign_medium'];
		$campaign_name = $request_param['campaign_name'];
		$brand_name = $request_param['brand_name'];
		//$encryptedURL = $request_param['encryptedURL'];
		if ($user_id && $start && $end && !empty($portfolios)) {
			if(isset($_REQUEST['ID'])){
				$post_id = $_REQUEST['ID'];
			}else{
				$postarr = array(
					'post_title' => 'User Access '.$user_id,
					'post_type' => ACCESS_POST_TYPE,
					'post_status' => 'publish'
				);
				$post_id = wp_insert_post( $postarr, $wp_error );
			}
			update_post_meta( $post_id, '_access_start_date', $start );
			update_post_meta( $post_id, '_access_end_date', $end );
			update_post_meta( $post_id, '_accessible_portfolios', $portfolios );
			update_post_meta( $post_id, '_access_status', 'Active' );
			update_post_meta( $post_id, '_access_user', $user_id );
			update_post_meta( $post_id, '_access_medium', $medium );
			update_post_meta( $post_id, '_access_remarks', $remarks );
			update_post_meta( $post_id, '_access_campaign_source', $campaign_source );
			update_post_meta( $post_id, '_access_campaign_medium', $campaign_medium );
			update_post_meta( $post_id, '_access_campaign_name', $campaign_name );
			update_post_meta( $post_id, '_access_brand_name', $brand_name );
			return true;
		}else{
			$type = 'error';
        	$message = __( 'Data can not be empty', 'my-text-domain' );
        	add_settings_error(
		        'myUniqueIdentifyer',
		        esc_attr( 'settings_updated' ),
		        $message,
		        $type
		    );
			return false;
		}
	}

	public function process_bulk_action() {
		  //Detect when a bulk action is being triggered...
		  if ( 'access' === $this->current_action() ) {

		    // In our file that handles the request, verify the nonce.
		    $nonce = esc_attr( $_REQUEST['_wpnonce'] );

		    if ( ! wp_verify_nonce( $nonce, 'sp_apply_access' ) ) {
		      die( 'Go get a life script' );
		    }
		    else {
		      self::apply_access( $_REQUEST );

		      wp_redirect( admin_url( 'admin.php?page=wp_list_table_class' ) );
		      exit;
		    }

		  }

		  // If the delete bulk action is triggered
		  if ( ( isset( $_POST['action'] ) && $_POST['action'] == 'apply-access' )
		       || ( isset( $_POST['action2'] ) && $_POST['action2'] == 'apply-access' )
		  ) {

		    // loop over the array of record iCampaignPrizeIds and delete them
		    if(self::apply_access( $_REQUEST )){
		    	wp_redirect( admin_url( 'admin.php?page=wp_list_table_class' ) );
		    }
		  }
	}

	function extra_tablenav( $which ) {
	    global $wpdb;
	    if ( $which == "top" ){
	    	$content_post = get_post(5);
	        $content = $content_post->post_content;
			$tech_option = unserialize($content);
			$curr_tech_option = $_GET['technology_options'];

	    	$content_post = get_post(6);
	        $content = $content_post->post_content;
			$category = unserialize($content);
			$curr_category = $_GET['category'];

			$content_post = get_post(7);
	        $content = $content_post->post_content;
			$industry = unserialize($content);
			$curr_industry = $_GET['industries'];
	        ?>
	        <div class="alignright actions bulkactions">
	            <select name="technology_options" id="technology_options">
					<option value="">All Technology</option>
					<?php 
					foreach ($tech_option['choices'] as $key => $value) : ?>
							<option value="<?php echo $value;?>" <?php echo ($curr_tech_option== $value ? 'selected="selected"' : '');?>><?php echo $value;?></option>
					<?php endforeach;?>					
				</select>
				<select name="category" id="category">
					<option value="">All Category</option>
					<?php foreach ($category['choices'] as $key => $value) : ?>
							<option value="<?php echo $value;?>" <?php echo ($curr_category== $value ? 'selected="selected"' : '');?>><?php echo $value;?></option>
					<?php endforeach;?>					
				</select>
				<select name="industries" id="industries">
					<option value="">All Industries</option>
					<?php foreach ($industry['choices'] as $key => $value) : ?>
							<option value="<?php echo $value;?>" <?php echo ($curr_industry== $value ? 'selected="selected"' : '');?>><?php echo $value;?></option>
					<?php endforeach;?>					
				</select>
				<input type="button" value="Filter" class="button" id="portfolio-filter" />
	        </div>
	        <?php
	    }
	}
}//end of class