jQuery(document).ready(function($) {
	  var nowTemp = new Date();
    var now = new Date(nowTemp.getFullYear(), nowTemp.getMonth(), nowTemp.getDate(), 0, 0, 0, 0);
     
    var checkin = $('#dpd1').datepicker({
      onRender: function(date) {
        return date.valueOf() < now.valueOf() ? 'disabled' : '';
      }
    }).on('changeDate', function(ev) {
      if (ev.date.valueOf() > checkout.date.valueOf()) {
        var newDate = new Date(ev.date)
        newDate.setDate(newDate.getDate() + 1);
        checkout.setValue(newDate);
      }
      checkin.hide();
      $('#dpd2')[0].focus();
    }).data('datepicker');
    var checkout = $('#dpd2').datepicker({
      onRender: function(date) {
        return date.valueOf() <= checkin.date.valueOf() ? 'disabled' : '';
      }
    }).on('changeDate', function(ev) {
      checkout.hide();
    }).data('datepicker');


    /**
     * main date filter
     * @date   2016-06-21
     */
    var checkinlist = $('#dpd3').datepicker({
      onRender: function(date) {
        return '';
      }
    }).on('changeDate', function(ev) {
      //if (ev.date.valueOf() > checkout.date.valueOf()) {
        var newDate = new Date(ev.date)
        newDate.setDate(newDate.getDate() + 1);
        checkoutlist.setValue(newDate);
      //}
      checkinlist.hide();
      $('#dpd4')[0].focus();
    }).data('datepicker');
    var checkoutlist = $('#dpd4').datepicker({
      onRender: function(date) {
        return date.valueOf() <= checkinlist.date.valueOf() ? 'disabled' : '';
      }
    }).on('changeDate', function(ev) {
      checkoutlist.hide();
    }).data('datepicker');


    /**
     * filter data
     */
    $('#portfolio-filter').click(function(event) {
      var technology_options = $('#technology_options').val();
      var category = $('#category').val();
      var industries = $('#industries').val();
      var newUrl = location.href+'&technology_options='+technology_options+'&category='+category+'&industries='+industries;
      location.replace(newUrl);
    });

    $('#access-filter').click(function(event) {
      var users = $('#access_user').val();
      var access_status = $('#access_status').val();
      var dpd3 = $('#dpd3').val();
      var dpd4 = $('#dpd4').val();
      var newUrl = location.href+'&access_user='+users+'&access_status='+access_status+'&startdate='+dpd3+'&enddate='+dpd4;
      location.replace(newUrl);
    });

    getHistoryFromID();
    getLoginURLFromID();

    $('#access_user').change(function(event) {
      getHistoryFromID();
      getLoginURLFromID();
    });

    $('.utmcodes').change(function(event) {
      getLoginURLFromID();
    });

    function getHistoryFromID()
    {
      var user_id = $('#access_user').val();
      $.ajax({
        url: user.ajaxUrl,
        type: 'POST',
        data: {user_id: user_id, action:user.get_history_url},
        success: function(response){
          $('#history_table').html('');
          $('#history_table').append(response);
        },
      })
    }

    function getLoginURLFromID()
    {
      var user_id = $('#access_user').val();
      var utm_source = $('#campaign_source').val();
      var utm_medium = $('#campaign_medium').val();
      var utm_campaign = $('#campaign_name').val();
      $.ajax({
        url: user.ajaxUrl,
        type: 'POST',
        data: {user_id: user_id, utm_source:utm_source, utm_medium:utm_medium, utm_campaign:utm_campaign, action:user.get_user_login_url},
        success: function(response){
          response = $.parseJSON(response);
          $('#private-url').html('');
          $('#private-url').append(response.long_url);
          $('#short-url').html('');
          $('#short-url').append(response.short_url);
        },
      })
    }
});