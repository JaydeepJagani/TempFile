<?php
function edit_user_access() {
	global $wpdb;
?>
<style type="text/css">
	.mal-content{
		font-size: 11px;
	}
</style>
	<div class="wrap">
		<?php $usermeta = get_user_meta($_GET['ID']);	?>
		<h2>
		Edit User Access - <?php echo $usermeta['first_name'][0]?>
		</h2>
		    <?php 
				function generateRandomString($length = 10) {
				    $characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
				    $charactersLength = strlen($characters);
				    $randomString = '';
				    for ($i = 0; $i < $length; $i++) {
				        $randomString .= $characters[rand(0, $charactersLength - 1)];
				    }
				    return $randomString;
				}		
		    ?>
		<div id="poststuff">
			<div id="post-body" class="metabox-holder columns-2">
				<div id="post-body-content" style="width: 133%;">
					<div class="meta-box-sortables ui-sortable">
						<form method="post">
							<?php
								$user_id = $_REQUEST['ID'];
								$startdate = get_user_meta( $user_id, '_access_start_date', true );
								$start = $startdate?date('m/d/Y', $startdate):'';
								$enddate = get_user_meta( $user_id, '_access_end_date', true );
								$end = $enddate?date('m/d/Y', $enddate):'';
								$autologin = get_user_meta( $user_id, '_access_autologin_code', true );
								$encryptURL = $autologin?$autologin:generateRandomString(30);
							?>
							<label><?php _e( 'Access From', 'user-access' ); ?></label>
							<input type="date" value="<?php echo $start?$start:'';?>" name="startdate" id="dpd1"/>
							<label><?php _e( 'To', 'user-access' ); ?></label>
							<input type="date" value="<?php echo $end?$end:'';?>" name="enddate" id="dpd2"/>
							<input type="hidden" value="<?php echo $encryptURL?>" name="encryptedURL" />
							<?php
							$wp_list_table = new Portfolio_List_Table();
							$wp_list_table->prepare_items($_POST);
							$wp_list_table->display();
							?>
							<h3>Auto Login URL: </h3>
							<?php echo site_url() . "?autologin_code=" . $encryptURL?>
						</form>						
					</div>
				</div>
			</div>
			<br class="clear">
		</div>
	</div>
	
<?php
}