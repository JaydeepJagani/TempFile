<?php
function user_list() {
	global $wpdb;
?>
<style type="text/css">
	.mal-content{
		font-size: 11px;
	}
</style>
	<div class="wrap">
		<h2>
		User List
		</h2>
		   <?
		    $campaign = $wpdb->get_results("SELECT iCampaignId,vName from Campaign");
		    $nonce = wp_create_nonce("fetch_week_campaign_nonce");
		   ?>
		   	<form method="post" action="<?php echo $_SERVER['REQUEST_URI']; ?>" id="search-form">
			    <select name="iCampaignId" id="campaign" data-nonce="<?php echo $nonce; ?>">
					<?php foreach($campaign as $r){?>
						<option value="<?php echo $r->iCampaignId?>" <?php echo $r->iCampaignId==$_POST['iCampaignId']?'selected="selected"':'';?>><?php echo $r->vName;?></option>
					<?php }?>
				</select>
				<input type="hidden" id="ajaxurl" value="<?php echo admin_url( 'admin-ajax.php' );?>">
				<input type="hidden" id="siteurl" value="<?php echo site_url();?>">
				<select name="iCampaignWeekId" id="campaignweek">
				</select>
				<noscript><input type="submit" value="Submit"></noscript>
				<a class="add-new-h2 csv-export" style="float:right;margin-right: 30px;" href="javascript:">CSV Export</a>
			</form>
		<div id="poststuff">
			<div id="post-body" class="metabox-holder columns-2">
				<div id="post-body-content" style="width: 133%;">
					<div class="meta-box-sortables ui-sortable">
						<form method="post">
							<?php
							$wp_list_table = new User_List_Table();
							$wp_list_table->prepare_items();
							$wp_list_table->display();
							?>
						</form>
					</div>
				</div>
			</div>
			<br class="clear">
		</div>
	</div>
	<script type="text/javascript">
		jQuery(document).ready(function(){
			var nonce = jQuery('#campaign').attr("data-nonce");
			var campaign = jQuery('#campaign').val();
			fetch_weeks(campaign, nonce);
			jQuery('#campaign').change(function(){
				var campaign = jQuery('#campaign').val();
				var nonce = jQuery(this).attr("data-nonce");
				fetch_weeks(campaign, nonce);
				fetch_users(campaign, nonce, 'campaign')
				//jQuery('#search-form').trigger('submit');
			});
			jQuery('#campaignweek').change(function(){
				var campaign = jQuery('#campaignweek').val();
				var nonce = jQuery('#campaign').attr("data-nonce");
				fetch_users(campaign, nonce, 'campaignweek')
				//jQuery('#search-form').trigger('submit');
			});
			jQuery('.status-change').click(function(){
				var con = confirm('Are you sure you want to declare this user as a winner?');
				if(con){}else{return false;}
			})
			jQuery('.csv-export').click(function(){
				var campaignweek = jQuery('#campaignweek').val();
				var siteurl = jQuery('#siteurl').val();
				location.replace(siteurl+'/wp-admin/admin.php?page=generate_csv&post='+campaignweek);
			})
		});

		function fetch_weeks(campaign, nonce){
			var ajaxurl = jQuery('#ajaxurl').val();
			jQuery.ajax({
		         type : "post",
		         dataType : "json",
		         url : ajaxurl,
		         data : {action: "fetch_week_campaign", post_id : campaign, nonce: nonce},
		         success: function(response) {
		         	var selectweek = jQuery('#week').val();
					if (response.length != 0 && selectweek == 'Select Week') {jQuery('#week').val(response[0]['iCampaignWeekId']);};		         	
		         	jQuery('#campaignweek').html('');
		         	if(response.length != 0){
		         		jQuery(response).each(function(i, v){
		         			var selected = selectweek == v['iCampaignWeekId']?'selected="selected"':'';
		            		var week = '<option value="'+v['iCampaignWeekId']+'" '+selected+'>'+v['vWeekTitle']+'</option>';
		            		jQuery('#campaignweek').append(week);
		            	});
		         	}else{
		            	var week = '<option value="all">Select Week</option>';
		            	jQuery('#campaignweek').append(week);
		         	}
		         }
		      })  
		}

		function fetch_users(campaign, nonce, post){
			var ajaxurl = jQuery('#ajaxurl').val();
			jQuery.ajax({
		         type : "post",
		         dataType : "json",
		         url : ajaxurl,
		         data : {action: "fetch_campaign_users", post_id : campaign, nonce: nonce, post : post},
		         success: function(response) {
		         	var siteurl = jQuery('#siteurl').val();
		         	var selectweek = jQuery('#week').val();
					if (response.length != 0 && selectweek == 'Select Week') {jQuery('#week').val(response[0]['iCampaignWeekId']);};		         	
		         	jQuery('#the-list').html('');
		         	if(response.length != 0){
		         		jQuery(response).each(function(i, v){
		         			if(v['vImgURL'] == ''){
		         				var imagepath = siteurl+'/wp-content/plugins/DHL-compitation/price_images/no-image.png';
		         			}else{
		         				var imagepath = v['vImgURL'];
		         			}

		         			v['winner'] = v['winner'] == 0?'<a href="'+siteurl+'/wp-admin/admin.php?page=declare_winner&amp;post='+v['iRegistrationUserId']+'" style="top: 0;" class="add-new-h2 status-change">Declare Winner</a>':'Winner';
		         			var date = v['dRegistrationDate'].split('-');
		         			v['dRegistrationDate'] = date[1]+'-'+date[2]+'-'+date[0];
		            		var week = '<tr><td data-colname="Image" class="vImgURL column-vImgURL has-row-actions column-primary"><img width="50px" height="50px" src="'+imagepath+'"><button class="toggle-row" type="button"><span class="screen-reader-text">Show more details</span></button></td><td data-colname="User Info" class="vName column-vName">'+v['vName']+' '+v['vLastName']+'<br><b>Email:</b><span class="mal-content"> '+v['vEmail']+'</span><br><b>Cell:</b> <span class="mal-content">'+v['vCellNumber']+'</span></td><td data-colname="Store Name" class="vStoreName column-vStoreName">'+v['vStoreName']+'</td><td data-colname="Date" class="dRegistrationDate column-dRegistrationDate">'+v['dRegistrationDate']+'</td><td data-colname="FB Share" class="iTotalShareFB column-iTotalShareFB">'+v['iTotalShareFB']+'</td><td data-colname="Twitter Share" class="iTotalShareTW column-iTotalShareTW">'+v['iTotalShareTW']+'</td><td data-colname="Entry For" class="eEntryFor column-eEntryFor">'+v['eEntryFor']+'</td><td data-colname="Status" class="winner column-winner">'+v['winner']+'</td></tr>';
		            		jQuery('#the-list').append(week);
		            	});
		         	}else{
		            	jQuery('#the-list').append('<tr class="no-items"><td colspan="4" class="colspanchange">No items found.</td></tr>');
		         	}
		         }
		      })  
		}
	</script>
<?php
}