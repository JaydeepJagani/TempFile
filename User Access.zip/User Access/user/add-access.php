<?php
function add_user_access(){
		global $wpdb;
		$post_id = $_GET['ID'];
		settings_errors();
?>
<style type="text/css">
	.mal-content{
		font-size: 11px;
	}
</style>
	<div class="wrap">
		<?php if ($_GET['ID']) {
			echo "<h2>edit_comment(); Access</h2>";
		}else{
			echo "<h2>Give New Access</h2>";
		}?>
		<div id="poststuff">
			<div id="post-body" class="metabox-holder columns-2">
				<div id="post-body-content" style="width: 133%;">
					<div class="meta-box-sortables ui-sortable">
						<form method="post">
							<?php
								$startdate = get_post_meta( $post_id, '_access_start_date', true );
								$start = $startdate?date('m/d/Y', $startdate):'';
								$curruser = get_post_meta( $post_id, '_access_user', true );
								$currstatus = get_post_meta( $post_id, '_access_medium', true );
								$currstatus = $currstatus?$currstatus:'Website';
								$remarks = get_post_meta( $post_id, '_access_remarks', true );
								$remarks = $remarks?$remarks:'';
								$campaign_source = get_post_meta( $post_id, '_access_campaign_source', true );
								$campaign_source = $campaign_source?$campaign_source:'';
								$campaign_medium = get_post_meta( $post_id, '_access_campaign_medium', true );
								$campaign_medium = $campaign_medium?$campaign_medium:'';
								$campaign_name = get_post_meta( $post_id, '_access_campaign_name', true );
								$campaign_name = $campaign_name?$campaign_name:'';
								$brand_name = get_post_meta( $post_id, '_access_brand_name', true );
								$brand_name = $brand_name?$brand_name:'';
								$enddate = get_post_meta( $post_id, '_access_end_date', true );
								$end = $enddate?date('m/d/Y', $enddate):'';
								$users = get_users( 'role=subscriber' );
							?>
							<div class="row">
								<div class="col-md-4">
									<label for="access_user">Select User</label>
									<select name="access_user" id="access_user" class="form-control">
										<option value="">- Select -</option>
										<?php
										foreach ($users as $key => $value) {
											$selected = getselected($curruser, $value->ID);
											echo '<option value="'.$value->ID.'" '.$selected.'>'.$value->data->display_name.'</option>';
										}
										?>
									</select>
								</div>
								<div class="col-md-8" id="history_table">

								</div>
							</div><br>
							<div class="row">
								<div class="col-md-4">
									<label for="dpd1"><?php _e( 'From', 'user-access' ); ?></label>
									<input type="text" class="form-control" value="<?php echo $start?$start:'';?>" name="startdate" id="dpd1"/>
								</div>
								<div class="col-md-4">
									<label for="dpd2"><?php _e( 'To', 'user-access' ); ?></label>
									<input type="text" class="form-control" value="<?php echo $end?$end:'';?>" name="enddate" id="dpd2"/>
									<input type="hidden" value="<?php echo $encryptURL?>" name="encryptedURL" />
								</div>
							</div><br>
							<div class="row">
								<div class="col-md-5">
									<label>Medium</label>
									<br>
									<label class="radio-inline"><input type="radio" value="Website" name="access_medium" <?php echo getselected($currstatus, 'Website', 'radio');?>>Website</label>
									<label class="radio-inline"><input type="radio" value="Portal" name="access_medium" <?php echo getselected($currstatus, 'Portal', 'radio');?>>Portal</label>
									<label class="radio-inline"><input type="radio" value="Phone" name="access_medium" <?php echo getselected($currstatus, 'Phone', 'radio');?>>Phone</label>
									<label class="radio-inline"><input type="radio" value="Email" name="access_medium" <?php echo getselected($currstatus, 'Email', 'radio');?>>Email</label>
									<label class="radio-inline"><input type="radio" value="Othres" name="access_medium" <?php echo getselected($currstatus, 'Othres', 'radio');?>>Othres</label>
								</div>
							</div><br>
							<div class="row">
								<div class="col-md-4">
									<label for="access_remarks">Remarks</label>
									<textarea name="access_remarks" id="access_remarks" class="form-control" maxlength="255" rows="5"><?php echo $remarks;?></textarea>
								</div>
							</div>
							<div class="row">
								<div class="col-md-4">
									<label for="access_brand_name">Brand Name</label>
									<input name="brand_name" id="access_brand_name" type="text" class="form-control" value="<?php echo $brand_name;?>">
								</div>
							</div>
							<br>
							<h4><u>Googel Analytics</u></h4>
							<div class="row">
								<div class="col-md-4">
									<label for="campaign_source">Campaign Source</label>
									<input type="text" name="campaign_source" id="campaign_source" data-query="utm_source" class="form-control utmcodes" value="<?php echo $campaign_source; ?>">
								</div>
								<div class="col-md-4">
									<label for="campaign_medium">Campaign Medium</label>
									<input type="text" name="campaign_medium" id="campaign_medium" data-query="utm_medium" class="form-control utmcodes" value="<?php echo $campaign_medium; ?>">
								</div>
								<div class="col-md-4">
									<label for="campaign_name">Campaign Name</label>
									<input type="text" name="campaign_name" id="campaign_name" data-query="utm_campaign" class="form-control utmcodes" value="<?php echo $campaign_name; ?>">
								</div>
							</div>
							<br>
							<?php
							$wp_list_table = new Portfolio_List_Table();
							$wp_list_table->prepare_items($_POST);
							$wp_list_table->display();
							?>
							<br>
							<p>
								<span><strong>Direct URL:</strong> </span>
								<span id="private-url">No URL Found.</span>
							</p>
							<p>
								<span><strong>Short URL:</strong> </span>
								<span id="short-url">No URL Found.</span>
							</p>
						</form>						
					</div>
				</div>
			</div>
			<br class="clear">
		</div>
	</div>
	
<?php
}

function getselected($main, $current, $element='dropdown'){
	switch ($element) {
		case 'radio':
			return $main==$current?'checked="checked"':'';
			break;
		
		default:
			return $main==$current?'selected="selected"':'';
			break;
	}
}