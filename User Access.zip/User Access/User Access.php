<?php 
/*
Plugin Name: User Access
Description: Plugin will give access of portfolio to the different user with Filter
Author: A1Brains
Version: 1.0
*/
?>
<?php

define('ACCESS_POST_TYPE', 'user-access');


// function to create the DB / Options / Defaults					
function user_access_install() {
   	require_once(ABSPATH . 'wp-admin/includes/upgrade.php'); 
    global $wpdb;
    $charset_collate = $wpdb->get_charset_collate();
    $sql = "DROP TABLE IF EXISTS `a1b_user_access`;
          CREATE TABLE IF NOT EXISTS `a1b_user_access` (
          `iAccessID` int(11) NOT NULL AUTO_INCREMENT,
          `iUserId` int(11) NOT NULL,
          `vUserName` varchar(255) NOT NULL,
          `dStartDate` date NOT NULL,
          `dEndDate` date NOT NULL,
          `vAccessIp` varchar(255) NOT NULL,
          `vPortfolioId` varchar(255) NOT NULL,
          `eStatus` enum('Active','Inactive') NOT NULL DEFAULT 'Inactive',
          PRIMARY KEY (`iAccessID`)
        ) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;";         
    dbDelta($sql); 	
}

function user_access_uninstall(){
  global $wpdb;
  $wpdb->query( "DROP TABLE IF EXISTS 'a1b_user_access'" );

	//if uninstall not called from WordPress exits
	if ( !defined( 'WP_UNINSTALL_PLUGIN' ) )
 	    exit();

  
}
// run the install scripts upon plugin activation
register_activation_hook(__FILE__,'user_access_install');
// run the uninstall scripts upon plugin
register_uninstall_hook(__FILE__,'user_access_uninstall'); 

/**
 * Enqueue scripts
 *
 * @param string $handle Script name
 * @param string $src Script url
 * @param array $deps (optional) Array of script names on which this script depends
 * @param string|bool $ver (optional) Script version (used for cache busting), set to null to disable
 * @param bool $in_footer (optional) Whether to enqueue the script before </head> or before </body>
 */
function rma_scripts() {
  wp_enqueue_script( 'bootstrap', plugin_dir_url( __FILE__ ).'js/bootstrap.min.js', array( 'jquery' ), false, true);
  wp_enqueue_script( 'bootstrap-datepicker', plugin_dir_url( __FILE__ ).'js/bootstrap-datepicker.js', array( 'jquery' ), false, true);
  wp_enqueue_script( 'user-access-functions', plugin_dir_url( __FILE__ ).'js/user-access-functions.js', array( 'jquery' ), false, true);
  wp_enqueue_style( 'datepicker', plugin_dir_url( __FILE__ ).'css/datepicker.css', array(), '1.0' );
  wp_enqueue_style( 'bootstrap', plugin_dir_url( __FILE__ ).'css/bootstrap.css', array(), '1.0' );
  wp_localize_script( 
    'user-access-functions',
    'user',
    array(
      'ajaxUrl'             => admin_url( 'admin-ajax.php' ),
      'get_history_url'     => 'getUserAccesshistory',
      'get_user_login_url'  => 'getUserLoginURL'
    ) 
  );
}

add_action( 'admin_enqueue_scripts', 'rma_scripts' );

//allow redirection, even if my theme starts to send output to the browser
add_action('init', 'do_output_buffer');
function do_output_buffer() {
        ob_start();
}

class SP_Plugin {

  // class instance
  static $instance;

  // customer WP_List_Table object
  public $customers_obj;

  // class constructor
  public function __construct() {
    add_filter( 'set-screen-option', [ __CLASS__, 'set_screen' ], 10, 3 );
    add_action( 'admin_menu', [ $this, 'plugin_menu' ] );
  }

  public static function set_screen( $status, $option, $value ) {
    return $value;
  }

  public function plugin_menu() {

    $hook = add_menu_page(
      'Access',
      'Access',
      'manage_options',
      'wp_list_table_class',
      [ $this, 'plugin_settings_page' ],
      'dashicons-editor-expand'
    );
    add_submenu_page(null, //parent slug
      'Edit User Access', //page title
      'Edit User Access', //menu title
      'manage_options', //capability
      'edit_user_access', //menu slug
      'edit_user_access'
    );
    add_submenu_page('wp_list_table_class', //parent slug
      'Add Access', //page title
      'Add Access', //menu title
      'manage_options', //capability
      'add_user_access', //menu slug
      'add_user_access'
    );

    $this->customers_obj = new User_List_Table();
  }

  /**
  * Plugin settings page
  */
  public function plugin_settings_page() {
    ?>
    <style>
      #ftitle{
        width: 240px;
      }
    </style>
    <div class="wrap">
      <h2>
      Access List
      <a class="page-title-action" href="<?php echo admin_url( 'admin.php?page=add_user_access' );?>">Add New</a>
      </h2>

      <div id="poststuff">
        <div id="post-body" class="metabox-holder columns-2">
          <div id="post-body-content" style="width: 133%;">
            <div class="meta-box-sortables ui-sortable">
              <form method="post">
               <input type="hidden" name="page" value="example_list_table" />
                <?php
                $this->customers_obj->prepare_items();
                $this->customers_obj->display(); ?>
              </form>
            </div>
          </div>
        </div>
        <br class="clear">
      </div>
    </div>    
  <?php
  }
    /** Singleton instance */
    public static function get_instance() {
      if ( ! isset( self::$instance ) ) {
        self::$instance = new self();
      }

      return self::$instance;
    }
  }

  add_action( 'plugins_loaded', function () {
    SP_Plugin::get_instance();
  } );

  define('ROOTDIR', plugin_dir_path(__FILE__));

  define('PKG_AUTOLOGIN_VALUE_GET', 'autologin_code');

  require_once(ROOTDIR . 'class/wp_list_table_user.php');
  require_once(ROOTDIR . 'class/wp_list_table_portfolio.php');
  require_once(ROOTDIR . 'user/edit_user_access.php');
  require_once(ROOTDIR . 'user/add-access.php');
  require_once(ROOTDIR . 'URL-Shortner/url-shortner.php');

  // Hook general init to login users if an autologin code is specified
  add_action('init', 'pkg_autologin_authenticate');
  function pkg_autologin_authenticate() {
    global $wpdb;

    // Check if autologin link is specified - if there is one the work begins
    if (isset($_GET[PKG_AUTOLOGIN_VALUE_GET])) {    
      $autologin_code = preg_replace('/[^a-zA-Z0-9]+/', '', $_GET[PKG_AUTOLOGIN_VALUE_GET]);
      if ($autologin_code) { // Check if not empty
        // Get part left of ? of the request URI for resassembling the target url later
        $subURIs = array();

        if (preg_match('/^([^\?]+)\?/', $_SERVER["REQUEST_URI"], $subURIs) === 1) {
          $targetPage = $subURIs[1];
          
          // Query login codes
          $loginCodeQuery = $wpdb->prepare("SELECT user_id FROM $wpdb->usermeta WHERE meta_value = '%s';", $autologin_code); // $autologin_code has been heavily cleaned before
          $userIds = $wpdb->get_col($loginCodeQuery);
          
          // Double login codes? should never happen - better safe than sudden admin rights for someone :D
          if (count($userIds) > 1) {
            wp_die("Please login normally - this is a statistic bug and prevents you from using login links securely!"); // TODO !!!
          }

          // Only login if there is only ONE possible user
          if (count($userIds) == 1) {
            $userToLogin = get_user_by('id', (int) $userIds[0]);
          
            // Check if user exists
            if ($userToLogin) {
              wp_set_current_user($userToLogin->ID, $userToLogin->data->user_login);
              wp_set_auth_cookie($userToLogin->ID, false);
              $SimpleLoginLog = new SimpleLoginLog;
              $SimpleLoginLog->login_success($userToLogin->user_login);
              do_action('wp_login', $userToLogin->name, $userToLogin);

              // Create redirect URL without autologin code
              $GETQuery = pkg_autologin_generate_get_postfix();
              wp_redirect('http://' . $_SERVER['HTTP_HOST'] . $targetPage . $GETQuery);
              exit;
            }
          }
        } 
      }
      
      // If something went wrong send the user to login-page (and log the old user out if there was any)
      wp_logout();
      wp_redirect(home_url('wp-login.php?pkg_autologin_error=invalid_login_code'));
      exit;
    }
  }

  function pkg_autologin_generate_get_postfix() {
    $GETcopy = $_GET;
    unset($GETcopy[PKG_AUTOLOGIN_VALUE_GET]);
    $GETQuery = pkg_autologin_join_get_parameters($GETcopy);
    if (strlen($GETQuery) > 0) {
      $GETQuery = '?' . $GETQuery;
    }
    return $GETQuery;
  }

  /**
 * <p>Joins the array-list of parameters to a correct GET-request parameter list. For example:</p>
 * 
 * <p>array('a' => 1, 'b' => 2, 'c' => 3) becomes a=1&b=2&c=3</p>
 * 
 * @param $parameters
 *   The parameters to join together to form the GET-request url part
 * @return
 *   The formed get-request string
 */
function pkg_autologin_join_get_parameters($parameters) {
  $keys = array_keys($parameters);
  $assignments = array();
  foreach ($keys as $key) {
    $assignments[] = "$key=$parameters[$key]";
    
  }
  return implode('&', $assignments);
}

/**
* Registers a new post type
* @uses $wp_post_types Inserts new post type object into the list
*
* @param string  Post type key, must not exceed 20 characters
* @param array|string  See optional args description above.
* @return object|WP_Error the registered post type object, or an error object
*/
function access_user_custom_post() {

  $labels = array(
    'name'                => __( 'Access', 'user-access' ),
    'singular_name'       => __( 'Access', 'user-access' ),
    'add_new'             => _x( 'Add New Access', 'user-access', 'user-access' ),
    'add_new_item'        => __( 'Add New Access', 'user-access' ),
    'edit_item'           => __( 'Edit Access', 'user-access' ),
    'new_item'            => __( 'New Access', 'user-access' ),
    'view_item'           => __( 'View Access', 'user-access' ),
    'search_items'        => __( 'Search Access', 'user-access' ),
    'not_found'           => __( 'No Access found', 'user-access' ),
    'not_found_in_trash'  => __( 'No Access found in Trash', 'user-access' ),
    'parent_item_colon'   => __( 'Parent Access:', 'user-access' ),
    'menu_name'           => __( 'Access', 'user-access' ),
  );

  $args = array(
    'labels'                   => $labels,
    'hierarchical'        => false,
    'description'         => 'description',
    'taxonomies'          => array(),
    'public'              => true,
    'show_ui'             => false,
    'show_in_menu'        => false,
    'show_in_admin_bar'   => false,
    'menu_position'       => null,
    'menu_icon'           => null,
    'show_in_nav_menus'   => true,
    'publicly_queryable'  => true,
    'exclude_from_search' => false,
    'has_archive'         => true,
    'query_var'           => true,
    'can_export'          => true,
    'rewrite'             => true,
    'capability_type'     => 'post',
    'supports'            => array(
      'title'
      )
  );

  register_post_type( ACCESS_POST_TYPE, $args );
}

add_action( 'init', 'access_user_custom_post' );

/**
 * to get user history from id
 */
add_action( 'wp_ajax_nopriv_getUserAccesshistory', 'getUserAccesshistory' );
add_action( 'wp_ajax_getUserAccesshistory', 'getUserAccesshistory' );
function getUserAccesshistory()
{
  $args = array(
    'post_type' => ACCESS_POST_TYPE,
    'posts_per_page' => 5,
  );

  $args['meta_query']['relation'] = 'AND';
  $args['meta_query'][] = array(
    'key'     => '_access_user',
    'value'   => $_POST['user_id'],
    'compare' => '='
  );
  $wp_query = new WP_Query( $args );
  ?>
  <table class="table">
    <thead>
      <th>Start Date</th>
      <th>End Date</th>
      <th>Category</th>
      <th>Status</th>
      <th>History</th>
    </thead>
    <tbody>
    <?php
    if ($wp_query->have_posts()) {
      while ($wp_query->have_posts()) { $wp_query->the_post(); ?>
        <tr>
          <td><?php 
              $startdate = get_post_meta( get_the_ID(), '_access_start_date', true );
              $start = date('F j,Y', $startdate);
              echo $start; ?></td>
          <td><?php 
              $enddate = get_post_meta( get_the_ID(), '_access_end_date', true );
              $end = date('F j,Y', $enddate);
              echo $end ?></td>
          <td><?php $portfolios = get_post_meta( get_the_ID(), '_accessible_portfolios', true );
          $category = array();
          foreach ( $portfolios as $key => $value ) {
              $categories = get_post_meta( $value, 'technology_options', true );
            $category = array_merge( $categories, $category );
          }
          echo implode( ", ", array_unique( $category ) );
          ?></td>
          <?php 
            $status = get_post_meta( get_the_ID(), '_access_status', true );
            $status = $status=='Inactive'?'<span class="label label-danger">Inactive</span>':'<span class="label label-primary">Active</span>';
          ?>
          <td><?php echo $status; ?></td>
          <?php
            $user_data = get_user_by( 'ID', $_POST['user_id'] );
            $user_login = $user_data->data->user_login;
          ?>
          <td><a class="badge" href="<?php echo admin_url( 'users.php?page=login_log&filter=' . $user_login );?>" target="_blank">View</a></td>
        </tr>
      <?php }
    }else{
      echo "<tr><td colspan='4'>No history found.</td></tr>";
    }
    ?>
    </tbody>
  </table>
  <?php
  wp_die();
}

/**
 * to get user history from id
 */
add_action( 'wp_ajax_nopriv_getUserLoginURL', 'getUserLoginURL' );
add_action( 'wp_ajax_getUserLoginURL', 'getUserLoginURL' );
function getUserLoginURL()
{
  if (isset($_POST['user_id']) && $_POST['user_id']) {
     $autologin = get_user_meta( $_POST['user_id'], '_access_autologin_code', true );
   }else{
    echo json_encode(array('long_url'=>'No URL Found.', 'short_url'=>'No URL Found.'));
    wp_die( );
   }

   if (isset($autologin) && $autologin) {
     $encryptURL = $autologin;
   }else{
      $encryptURL = generateRandomString(30);
      update_user_meta( $_POST['user_id'], '_access_autologin_code', $encryptURL );
   }

  $utm_source = $_POST['utm_source'];
  $utm_medium = $_POST['utm_medium'];
  $utm_campaign = $_POST['utm_campaign'];

  $utmcodes = $utm_source?"&utm_source=" . $utm_source:"";
  $utmcodes .= $utm_medium?"&utm_medium=" . $utm_medium:"";
  $utmcodes .= $utm_campaign?"&utm_campaign=" . $utm_campaign:"";

  // Create instance with key
  $key = 'AIzaSyChiFHjE4hxEgIdT1kxqT-S7Cq2F9f3hPE';
  $googer = new GoogleURLAPI($key);

  // Test: Shorten a URL
  $longurl = site_url() . "?autologin_code=" . $encryptURL . $utmcodes;
  $shortDWName = $googer->shorten($longurl);
  if ($shortDWName)
    echo json_encode(array('long_url'=>$longurl, 'short_url'=>$shortDWName));
  else
    echo json_encode(array('long_url'=>$longurl, 'short_url'=>'No URL Found.'));
  wp_die();
}

function generateRandomString($length = 10) {
    $characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
    $charactersLength = strlen($characters);
    $randomString = '';
    for ($i = 0; $i < $length; $i++) {
        $randomString .= $characters[rand(0, $charactersLength - 1)];
    }
    return $randomString;
}