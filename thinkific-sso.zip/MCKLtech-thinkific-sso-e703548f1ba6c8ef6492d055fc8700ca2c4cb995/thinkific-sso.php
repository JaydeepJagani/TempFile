<?php
/*
 * Plugin Name: Thinkific SSO for WordPress
 * Plugin URI:  https://www.wooninja.io/?utm_source=wp-plugins&utm_campaign=plugin-uri&utm_medium=wp-dash
 * Description: An SSO Solution for WordPress & Thinkific
 * Version: 1.0.1
 * Author: Colin Longworth
 * Author URI: https://www.wooninja.io/?utm_source=wp-plugins&utm_campaign=thinkific-sso&utm_medium=wp-dash
 * Text Domain: thinkific-sso
 *
 * WordPress is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * any later version.
 *
 * WordPress is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 */

if ( ! defined( 'ABSPATH' ) ) exit;

define( 'THINKIFIC_SSO_VERSION', '1.0.1' ); 
define( 'THINKIFIC_SSO_PREVIOUS_STABLE_VERSION', '1.0' ); 
define( 'THINKIFIC_SSO_NAME', 'Thinkific SSO for WordPress' ); 

define( 'THINKIFIC_SSO__FILE__', __FILE__ );
define( 'THINKIFIC_SSO_PLUGIN_BASE', plugin_basename( THINKIFIC_SSO__FILE__ ) );
define( 'THINKIFIC_SSO_PATH', plugin_dir_path( THINKIFIC_SSO__FILE__ ) );

define( 'THINKIFIC_SSO_URL', plugins_url( '/', THINKIFIC_SSO__FILE__ ) );

define( 'THINKIFIC_SSO_ASSETS_PATH', THINKIFIC_SSO_PATH . 'assets/' );

define( 'THINKIFIC_SSO_ASSETS_URL', THINKIFIC_SSO_URL . 'assets/' );


add_action( 'plugins_loaded', function (){
    load_plugin_textdomain( THINKIFIC_SSO_TEXT_DOMAIN, false, basename( dirname( __FILE__ ) ) . '/languages' );
} );

define( 'THINKIFIC_SSO_TEXT_DOMAIN', 'thinkific-sso' );

if ( ! version_compare( PHP_VERSION, '5.6', '>=' ) ) {
    add_action( 'admin_notices', function(){
        $message = sprintf( esc_html__( '%s requires PHP version %s+, plugin is currently NOT RUNNING.', THINKIFIC_SSO_TEXT_DOMAIN ), THINKIFIC_SSO_NAME, '5.6' );
        $html_message = sprintf( '<div class="notice notice-error">%s</div>', wpautop( $message ) );
        echo wp_kses_post( $html_message );
    } );
} 

elseif ( ! version_compare( get_bloginfo( 'version' ), '4.9', '>=' ) ) {
    add_action( 'admin_notices', function (){
        $message = sprintf( esc_html__( '%s requires WordPress version %s+. Because you are using an earlier version, the plugin is currently NOT RUNNING.', THINKIFIC_SSO_TEXT_DOMAIN ), THINKIFIC_SSO_NAME, '4.9' );
        $html_message = sprintf( '<div class="notice notice-error">%s</div>', wpautop( $message ) );
        echo wp_kses_post( $html_message );
    } );
        
} 
else {

    //We are ready to rock
    include_once( THINKIFIC_SSO_PATH . '/includes/plugin.php' );
     
    $iwp = new \ThinkificSSO\ThinkificSSO;
    
}