<?php

namespace ThinkificSSO;

if ( ! defined( 'ABSPATH' ) ) exit;

class ThinkificSSO {
    
    public $license_manager;
    
    public function __construct()
    {
        
        self::includes();
        
        add_shortcode( 'thinkific_sso', [$this, 'generate_thinkfic_sso_url'] );
        
        add_action( 'admin_menu', [$this, 'thinkific_sso_settings_page'] );
        
        add_action( 'admin_init', [$this, 'thinkific_sso_settings_init'] );
        
        $this->license_manager   = new License_Manager();  
    }
    
    public function includes() {
        
        require  THINKIFIC_SSO_PATH . '/includes/license-manager.php'; 
        
    }
    
    
    public function generate_thinkfic_sso_url($atts) {
        
    $options = get_option( 'thinkific_sso_settings' );
        
    $base_url = isset($options['thinkific_sso_domain']) ? 'https://'.$options['thinkific_sso_domain'] : site_url();
    
    $atts = shortcode_atts( array(
	    'prefix' => true,
	    'base_url' => $base_url,
        'return_to' => $base_url,
        'error_url' => $base_url,
    ), $atts );
    
    /* We can only proceed if the user is logged into WordPress */
    
    if(!is_user_logged_in() || !$user = wp_get_current_user()) {
         
        if($atts['prefix'] === 'false') {
            
            return preg_replace('#^https?://#', '', $base_url);
        }
        
        return $base_url;
    
    }
    
    // Create token header as a JSON string
    $header = json_encode(['typ' => 'JWT', 'alg' => 'HS256']);

    // Create token payload as a JSON string
    $payload = json_encode([
        'email' => $user->user_email,
        'first_name' => $user->first_name,
        'last_name' => $user->last_name,
        'iat' => time(),
    ]);

    // Encode Header to Base64Url String
    $base64UrlHeader = str_replace(['+', '/', '='], ['-', '_', ''], base64_encode($header));

    // Encode Payload to Base64Url String
    $base64UrlPayload = str_replace(['+', '/', '='], ['-', '_', ''], base64_encode($payload));

    // Create Signature Hash    
    $key = isset($options['thinkific_sso_api_key']) ? $options['thinkific_sso_api_key'] : '';
    
    $signature = hash_hmac('sha256', $base64UrlHeader . "." . $base64UrlPayload, $key, true);

    // Encode Signature to Base64Url String
    $base64UrlSignature = str_replace(['+', '/', '='], ['-', '_', ''], base64_encode($signature));

    // Create JWT
    $jwt = $base64UrlHeader . "." . $base64UrlPayload . "." . $base64UrlSignature;

    $baseUrl = $base_url."/api/sso/v2/sso/jwt?jwt=";
    
    if($atts['prefix'] === 'false') {
        
        $baseUrl = preg_replace('#^https?://#', '', $baseUrl);
        
    }
    
    $returnTo = urlencode($atts['return_to']);
    
    $errorUrl = urlencode($atts['error_url']);
    
    $url = $baseUrl . $jwt . "&return_to=" . $returnTo . "&error_url=" . $errorUrl;
    
    return $url;
    }

    /* Admin Settings Page */   
    
    public function thinkific_sso_settings_page() {
    add_options_page( 'Thinkific SSO', 'Thinkific SSO', 'manage_options', 'thinkific-sso', [$this, 'thinkific_sso_options_page'] );
}

    public function thinkific_sso_settings_init(  ) {
    
    register_setting( 'thinkificSSO', 'thinkific_sso_settings', [$this, 'thinkific_sso_validation'] );
    
    add_settings_section(
        'thinkificSSO_section',
        __( 'Thinkific API', THINKIFIC_SSO_TEXT_DOMAIN ),
        [$this, 'thinkific_sso_settings_section_callback'],
        'thinkificSSO'
    );

    add_settings_field(
        'thinkific_sso_domain',
        __( 'Domain', THINKIFIC_SSO_TEXT_DOMAIN ),
        [$this, 'thinkific_sso_render_field'],
        'thinkificSSO',
        'thinkificSSO_section',
        array('thinkific_sso_domain', 'example.thinkific.com')
    );
    
    add_settings_field(
        'thinkific_sso_api_key',
        __( 'API Key', THINKIFIC_SSO_TEXT_DOMAIN ),
        [$this, 'thinkific_sso_render_field'],
        'thinkificSSO',
        'thinkificSSO_section',
        array('thinkific_sso_api_key', 'XXXXc94b7d55d80f6c7daf594ddbXXXX')
    );
    
    add_settings_field(
        'thinkific_sso_license_key',
        __( 'License Key', THINKIFIC_SSO_TEXT_DOMAIN ),
        [$this, 'thinkific_sso_render_field'],
        'thinkificSSO',
        'thinkificSSO_section',
        array('thinkific_sso_license_key', 'XXXX7d16df8b8df0350e582e48bdXXXX')
    );
        
        add_settings_field(
        'thinkific_sso_license_btn',
        __( 'License Status', THINKIFIC_SSO_TEXT_DOMAIN ),
        [$this->license_manager, 'license_url'],
        'thinkificSSO',
        'thinkificSSO_section'
    );
}

    public function thinkific_sso_settings_section_callback(  ) {
    
        echo __( 'You will need to add your Thinkific API details exactly as they appear in your Thinkific Instructor dashboard.', THINKIFIC_SSO_TEXT_DOMAIN );
    }
    
    public function thinkific_sso_render_field($args) {
          
        $field = $args[0];
            
        $placeholder = isset($args[1]) ? $args[1] : '';
   
        $options = get_option( 'thinkific_sso_settings' );
            
        $value = isset($options[$field]) ? $options[$field] : '';
        
        ?>
    
        <input type='text' size='50' placeholder='<? echo $placeholder; ?>' name='thinkific_sso_settings[<?php echo $field; ?>]' value='<?php echo $value; ?>'>
        
        <?php
        
    }

    public function thinkific_sso_options_page(  ) {
    ?>
    <form action='options.php' method='post'>

        <h2>Settings</h2>

        <?php
            
        settings_fields( 'thinkificSSO' );
        
        do_settings_sections( 'thinkificSSO' );
        
        submit_button();
        
        ?>

    </form>
    <?php
    }
    
    public function thinkific_sso_validation($options) {
        
        if(isset($options['thinkific_sso_domain'])) {
            
            $url = $options['thinkific_sso_domain'];
            
            if (strpos($url, 'http') !== false) {
                
                //Do nothing
            }
            
            else {
                
                $url = preg_replace('#^https?://#', '', $url);
                
                $url = 'https://'.$url;
            }
            
            $url = parse_url($url);
                 
            $options['thinkific_sso_domain'] = isset($url['host']) ? $url['host'] : '';
             
        }
        
        return $options;
    }
    
}


?>