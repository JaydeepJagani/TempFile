<?php

namespace ThinkificSSO;

if (!defined('ABSPATH')) exit;

class License_Manager
{
    
    static $storeUrl = "https://www.wooninja.io";
    
    static $item_id = 1129;
    
    static $item_name = THINKIFIC_SSO_NAME;
    
    static $version = THINKIFIC_SSO_VERSION;
    
    static $transient_license_status = 'ThinkificSSOStatus';
    
    static $transient_license_last_check = 'ThinkificSSOLastCheck';
    
    static $plugin_file = THINKIFIC_SSO__FILE__;
    
    //The license WP Option
    static $option_key = 'thinkific_sso_license_key';
    
    public function __construct()
    {
        add_action('admin_init', [$this, 'check_license']);
        
        add_action( 'admin_init', [$this, 'edd_plugin_updater'] );
    }
    
    /**
     * Get the EDD updater.
     *
     * @return \EDD_GHMG_Plugin_Updater
     */
    public function edd_plugin_updater()
    {
        if ( ! class_exists('\EDD_WNTHINKIFIC_Plugin_Updater') ){
            require_once dirname(__FILE__) . '/lib/edd/EDD_WNTHINKIFIC_Plugin_Updater.php';
        }
        
        // retrieve our license key from the DB
	   $license_key = trim(get_option(static::$option_key));
        
        return new \EDD_WNTHINKIFIC_Plugin_Updater( static::$storeUrl, static::$plugin_file, [
            'version' 	=> static::$version,
            'license' 	=> $license_key,
            'item_id'   => static::$item_id,
            'author'    => 'Colin Longworth',
            'beta'       => false
        ] );
    }
    
    /**
     * Display the License Activation Button
     *
     * @return HTML
     */
    
    public function license_url()
    {
        
        $licenseKey = trim(get_option(static::$option_key));
            
        $licenseStatus = self::verify_license($licenseKey, static::$item_id);
            
        if(!$licenseStatus) {
            ?>
            <a href="<?php echo wp_nonce_url(add_query_arg('activate_'.static::$option_key, '1', $_SERVER['REQUEST_URI'])); ?>"
               class="button-primary"><?php _ex('Activate License', 'action', 'groundhogg') ?></a>
            <?php
                
        }
        
        else {
            
            ?>
            <a href="<?php echo wp_nonce_url(add_query_arg('deactivate_'.static::$option_key, '1', $_SERVER['REQUEST_URI'])); ?>"
               class="button-secondary"><?php _ex('Deactivate License', 'action', 'groundhogg') ?></a>
            <?php
        }
        
    }
 
    public function check_license()
    {   
        if ( ! current_user_can('manage_options' ) ) return;
        
        $options = get_option( 'thinkific_sso_settings' );
        
        $licenseKey = isset($options['thinkific_sso_license_key']) ? trim($options['thinkific_sso_license_key']) : false;
        
        //Check license is entered and valid
        
        if(empty($licenseKey)) {
            
            $message = _x( static::$item_name.' - Please enter your license key and click "Save Changes"', 'notice', 'groundhogg' );
                
            self::add_notice($message, 'error');
                
            return;
            
        }
             
        if (self::get_request_var('activate_'.static::$option_key)) {
            
            self::activate_license( $licenseKey, static::$item_id);
            
            return;
        
        }
        
        if (self::get_request_var('deactivate_'.static::$option_key)) {
            
            self::deactivate_license($licenseKey, static::$item_id);
              
            return;
        
        }
             
        $licenseStatus = self::verify_license($licenseKey, static::$item_id);
        
        if(!$licenseStatus) {
            
            $message = _x( static::$item_name.' - Your license is deactivated or invalid. Please check & activate your license.', 'notice', 'groundhogg' );
                
            $this->add_notice($message, 'error');
                
            return;
            
        }
        
    }
          
    public static function activate_license( $license, $item_id ) {
        
        $api_params = array(
            'edd_action' => 'activate_license',
            'license'    => $license,
            'item_id'    => $item_id,
            'url'        => home_url(),
	        'beta'      => false
		);
        
        $response = wp_remote_post( static::$storeUrl, array( 'timeout' => 15, 'sslverify' => true, 'body' => $api_params ) );
        
        //Check the response
		if ( is_wp_error( $response ) || 200 !== wp_remote_retrieve_response_code( $response ) ) {
            $message =  ( is_wp_error( $response ) && $response->get_error_message() ) ? $response->get_error_message() : __( 'We were unable to reach our servers to activate your license. Please try again.' );
        } else {
            
            $license_data = json_decode( wp_remote_retrieve_body( $response ) );
            
            if(empty($license_data)) return false;
            
            if ( false === $license_data->success ) {
                switch( $license_data->error ) {
                    case 'expired' :
                        $message = sprintf(
                            _x( 'Your license key expired on %s.', 'notice', 'groundhogg' ),
                            date_i18n( get_option( 'date_format' ), strtotime( $license_data->expires, current_time( 'timestamp' ) ) )
                        );
                        break;
                    case 'revoked' :
                        $message = _x( 'Your license key has been disabled.', 'notice', 'groundhogg' );
                        break;
                    case 'missing' :
                        $message = _x( 'Invalid license.', 'notice', 'groundhogg' );
                        break;
                    case 'invalid' :
                    case 'site_inactive' :
                        $message = _x( 'Your license is not active for this URL.', 'notice', 'groundhogg' );
                        break;
                    case 'item_name_mismatch' :
                        $message = sprintf( _x( 'This appears to be an invalid license key', 'notice', 'groundhogg' ) );
                        break;
                    case 'no_activations_left':
                        $message = _x( 'Your license key has reached its activation limit.' , 'notice', 'groundhogg' );
                        break;
                    default :
                        $message = _x( 'An error occurred, please try again.', 'notice', 'groundhogg' );
                        break;
                }
            }
        }
        
        //Check message
		if ( ! empty( $message ) ) {
            
            self::add_notice($message, 'error');
            
        } else {
			
            //Successful activation
            set_transient( static::$transient_license_status, 1 );
            
            self::add_notice(_x( 'License activated',  THINKIFIC_SSO_TEXT_DOMAIN), 'success');

        }
          
        return;
        
    }
    
    public static function deactivate_license($license, $item_id )
    {

	    $api_params = array(
		    'edd_action' => 'deactivate_license',
		    'item_id'    => $item_id,
		    'license'    => $license,
		    'url'        => home_url(),
	    );

	    $response = wp_remote_post( self::$storeUrl, array( 'body' => $api_params, 'timeout' => 15, 'sslverify' => false ) );

	    if ( is_wp_error( $response ) ){
	        $success = false;
	        $message = _x( static::$item_name.' - We were unable to reach our servers to deactivate your license. Please try again.', 'notice', 'groundhogg' );
        } else {
	        $response = json_decode( wp_remote_retrieve_body( $response ) );

	        if ( $response->success === false ){
		        $success = false;
		        $message = _x( static::$item_name.' - Something went wrong when we tried to deactivate your license. Please try again.', 'notice', 'groundhogg' );
	        } else {
		        $success = true;
		        $message = _x( static::$item_name.' - License deactivated.', 'notice', 'groundhogg' );
	        }
        }

        $type = $success ? 'success' : 'error';
	    
        self::add_notice($message, $type);
        
        if($success) {
            
            set_transient( static::$transient_license_status, 0 );
            
            delete_transient( static::$transient_license_last_check );
        }

	    return $success;
    }
    
    public static function verify_license($license,  $item_id  )
    {
    
        $lastCheck = get_transient( static::$transient_license_last_check );
        
        //Only check every 24 hours
        if($lastCheck && $lastCheck > (time() - DAY_IN_SECONDS)) {
            
            //Only return true if last check was valid
            if(get_transient( static::$transient_license_status )) {
                
                return true;
            }
        }
        
        set_transient( static::$transient_license_last_check, time() );
        
        $api_params = array(
            'edd_action' => 'check_license',
            'license' => $license,
            'item_id' => $item_id,
            'url' => home_url()
        );

        $response = wp_remote_post( static::$storeUrl, array( 'body' => $api_params, 'timeout' => 15, 'sslverify' => true ) );
        
        if ( is_wp_error( $response ) ) {
            //Return true for error. Temp set license as valid
            set_transient( static::$transient_license_status, 1 );
            return true;
        }

        $license_data = json_decode( wp_remote_retrieve_body( $response ) );
            
        if( isset( $license_data->license ) && $license_data->license != 'valid' ) {
            
            set_transient( static::$transient_license_status, 0 );
            
            return false;
        }
        
        set_transient( static::$transient_license_status, 1 );
        
        return true;
    }
    
    public static function add_notice($message, $type = 'success') {
         
        add_settings_error( 'thinkific_sso_settings', 'thinkific-sso', $message, $type ); 
    }
    
    private function get_request_var( $key = '', $default = false, $post_only = false )
    {
        $global = $post_only ? $_POST : $_REQUEST;
        return wp_unslash( self::get_array_var( $global, $key, $default ) );
    }
    
    private function get_array_var( $array, $key = '', $default = false )
    {
    if ( self::isset_not_empty( $array, $key ) ) {
        if ( is_object( $array ) ) {
            return $array->$key;
        } elseif ( is_array( $array ) ) {
            return $array[ $key ];
        }
    }

    return $default;
    }
    
    private function isset_not_empty( $array, $key = '' )
    {
    if ( is_object( $array ) ) {
        return isset( $array->$key ) && !empty( $array->$key );
    } elseif ( is_array( $array ) ) {
        return isset( $array[ $key ] ) && !empty( $array[ $key ] );
    }

    return false;
    }
}