<?php

namespace Eher\OAuth;

/* Generic exception class
 */
class OAuthException extends \Exception {
  // pass
}
