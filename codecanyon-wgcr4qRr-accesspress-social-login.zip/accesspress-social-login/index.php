<?php
//silence is golden

?>